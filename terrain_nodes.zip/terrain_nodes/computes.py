import bpy
import numpy
import ctypes
import time
import mathutils
import bmesh
import math
import os
from datetime import timedelta
from . import utils

abs_path = os.path.abspath(os.path.dirname(__file__)) + r'\terrain_nodes_8.0.dll'

if os.path.exists(abs_path):
    print('Loading DLL')
    dll_erosion = ctypes.cdll.LoadLibrary(abs_path)
else:
    print('Did not find DLL')

compute_functions = {}

def insert_func(foo):
    compute_functions[foo.__name__] = foo
    return foo

@insert_func
def GAEA_ND_math(tn_data, node):
    out_socket_name = node.outputs[0].name

    for n in node.inputs:
        if n.name == 'A':
            a = tn_data.get_socket_data(n)
        else:
            b = tn_data.get_socket_data(n)

    func = getattr(numpy, node.functions)
    result = func(a, b)
    result = result.clip(min=0)

    return {out_socket_name : result}

@insert_func
def GAEA_ND_scale(tn_data, node):
    out_socket_name = node.outputs[0].name
    input_node = node.inputs[0].links[0].from_node
    input_data = tn_data.get_socket_data(node.inputs[0], deepcopy=True)

    if input_node.get_width() == node.scale_width and input_node.get_height() == node.scale_height:
        return {out_socket_name : input_data}
    else:
        result = numpy.empty((node.scale_width * node.scale_height), dtype=numpy.float32)
        dll_erosion.scale(
            ctypes.c_void_p(input_data.ctypes.data),
            ctypes.c_void_p(result.ctypes.data),
            ctypes.c_int(input_node.get_width()),
            ctypes.c_int(input_node.get_height()),
            ctypes.c_int(node.scale_width),
            ctypes.c_int(node.scale_height)
            )

        return {out_socket_name : result}

@insert_func
def GAEA_ND_viewer(tn_data, node):
    input_node = node.inputs[0].links[0].from_node
    input_data = tn_data.get_socket_data(node.inputs[0])
    data = tn_data.state[node.name]

    preview_img_name = ('_preview_' + node.name)
    img = None

    if data:
        node.tex = data
        img = node.tex.image
        if img.name != preview_img_name:
            img.name = preview_img_name
    else:
        node.tex = bpy.data.textures.new(input_node.name, "IMAGE")
        node.tex.extension = 'EXTEND'

    height = node.get_height() // node.preview_resolution
    width = node.get_width() // node.preview_resolution

    if img:
        img.generated_height = height
        img.generated_width = width
    elif preview_img_name in bpy.data.images:
        img = bpy.data.images[preview_img_name]
        img.generated_width = width
        img.generated_height = height
    else:
        img = bpy.data.images.new(name=preview_img_name, width=width, height=height, alpha=False)
        img.file_format = 'TIFF'

    node.tex.image = img

    if node.preview_resolution > 1:
        result = numpy.empty((width * height), dtype=numpy.float32)
        dll_erosion.scale(
            ctypes.c_void_p(input_data.ctypes.data),
            ctypes.c_void_p(result.ctypes.data),
            ctypes.c_int(input_node.get_width()),
            ctypes.c_int(input_node.get_height()),
            ctypes.c_int(width),
            ctypes.c_int(height)
            )
        pixels = numpy.repeat(result, 4)
    else:
        pixels = result

    for i in range(len(pixels)):
        if (i+1) % 4 == 0:
            pixels[i] = 1

    node.tex.image.pixels = pixels.tolist()
    node.tex.image.update()

    return node.tex


@insert_func
def GAEA_ND_object_input(tn_data, node):
    bm = bmesh.new()
    obj = node.target_object
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()

    # find corners
    def is_corner(verts, target):
        if len(verts[target].link_faces) == 1:
            return True
        else:
            return False

    corners = []
    for v in bm.verts:
        if is_corner(bm.verts, v.index):
            corners.append(v.index)

    #find bottom left corner
    def get_bl_vert(verts, corners):
        bl_corner = 0
        for i in corners:
            bl_corner = i
            for j in corners:
                if i == j:
                    continue
                if bm.verts[bl_corner].co.y > bm.verts[j].co.y:
                    bl_corner = j
                elif bm.verts[bl_corner].co.x > bm.verts[j].co.x:
                    bl_corner = j
        return bl_corner

    def get_tr_vert(verts, corners):
        bl_corner = 0
        for i in corners:
            bl_corner = i
            for j in corners:
                if i == j:
                    continue
                if bm.verts[bl_corner].co.y < bm.verts[j].co.y:
                    bl_corner = j
                elif bm.verts[bl_corner].co.x < bm.verts[j].co.x:
                    bl_corner = j
        return bl_corner

    bl_corner = get_bl_vert(bm.verts, corners)

    # determine distance ratio
    #find connected verts
    attached_verts = [0,0] # X, Y
    for e in bm.verts[bl_corner].link_edges:
        if e.other_vert(bm.verts[bl_corner]) is None:
            continue
        if e.other_vert(bm.verts[bl_corner]).co.y > bm.verts[bl_corner].co.y:
            attached_verts[1] = e.other_vert(bm.verts[bl_corner]).index
        else:
            attached_verts[0] = e.other_vert(bm.verts[bl_corner]).index

    # fill grid based on coordinates
    x_edge = bm.verts[attached_verts[0]].co.x - bm.verts[bl_corner].co.x
    y_edge = bm.verts[attached_verts[1]].co.y - bm.verts[bl_corner].co.y

    # find height and width
    tr_corner = get_tr_vert(bm.verts, corners)
    node.object_width = math.ceil((bm.verts[tr_corner].co.x - bm.verts[bl_corner].co.x) // x_edge) + 1
    node.object_height = math.ceil((bm.verts[tr_corner].co.y - bm.verts[bl_corner].co.y) // y_edge) + 1

    # fill grid
    origin = bm.verts[bl_corner]
    height_map = numpy.empty((node.object_width, node.object_height), dtype=numpy.float32)
    for v in bm.verts:
        row = math.floor((v.co.y - origin.co.y) // y_edge)
        col = math.floor((v.co.x - origin.co.x) // x_edge)
        #loc = row * width + col
        height_map[row][col] = v.co.z

    bm.free()

    height_map = height_map.flatten()
    out_socket_name = node.outputs[0].name

    return {out_socket_name : height_map}


@insert_func
def GAEA_ND_noise_texture(tn_data, node):
    value_texture = numpy.zeros((node.noise_width * node.noise_height), dtype=numpy.float32)

    if node.noise_limits == 'abs':
        for y in range(node.noise_height):
            for x in range(node.noise_width):
                loc = y * node.noise_width + x
                value_texture[loc] = abs(mathutils.noise.fractal(
                    (x*node.scale, y*node.scale, 1),
                    node.factal_dim,
                    node.lacunarity,
                    node.octaves,
                    int(node.noises)))
    elif node.noise_limits == 'zero':
        for y in range(node.noise_height):
            for x in range(node.noise_width):
                loc = y * node.noise_width + x
                val = mathutils.noise.fractal(
                    (x*node.scale, y*node.scale, 1),
                    node.factal_dim,
                    node.lacunarity,
                    node.octaves,
                    int(node.noises))
                if val < 0:
                    value_texture[loc] = 0
                else:
                    value_texture[loc] = val
    else:
        for y in range(node.noise_height):
            for x in range(node.noise_width):
                loc = y * node.noise_width + x
                value_texture[loc] = mathutils.noise.fractal(
                    (x*node.scale, y*node.scale, 1),
                    #node.factal_dim,
                    node.lacunarity,
                    node.octaves,
                    int(node.noises))


    out_socket_name = node.outputs[0].name

    return {out_socket_name : value_texture}


#TODO: Check if image was updated and reload
@insert_func
def GAEA_ND_image_input(tn_data, node):
    if node.image.filepath:
        path = bpy.path.abspath(node.image.filepath)
        if os.path.exists(path):
            pixels = list(node.image.pixels)
            value_texture = numpy.asarray(pixels[::4], dtype=numpy.float32)
        else:
            raise ValueError('Image does not exist at specified location')

    out_socket_name = node.outputs[0].name

    return {out_socket_name : value_texture}


@insert_func
def GAEA_ND_output(tn_data, node):
    # save and get render scene settings
    #current_scene = bpy.context.scene
    tn_render_scene = None
    if '__terrain_nodes_image_save' in bpy.data.scenes:
        tn_render_scene = bpy.data.scenes['__terrain_nodes_image_save']
    else:
        tn_render_scene = bpy.data.scenes.new('__terrain_nodes_image_save')

    tn_render_scene.render.image_settings.file_format = 'OPEN_EXR'
    tn_render_scene.render.image_settings.color_mode = 'BW'
    tn_render_scene.render.image_settings.color_depth = '32'

    # save images
    input_node = node.inputs[0].links[0].from_node
    data = tn_data.state[node.name]

    st = {}

    if node.save_all:
        data_dic = tn_data.state[input_node.name]
        for key in data_dic:
            if data_dic[key] is None:
                continue
            utils.save_image(tn_render_scene, st, node, data, data_dic[key], key, dll_erosion)
    else:
        input_data = tn_data.get_socket_data(node.inputs[0])
        key = node.inputs[0].links[0].from_socket.name
        utils.save_image(tn_render_scene, st, node, data, input_data, key, dll_erosion)

    return st


@insert_func
def GAEA_ND_terrain_erosion(tn_data, node):
    layers = {}
    for o in node.outputs:
        layers[o.name] = None

    for n in node.inputs:
        if n.is_linked and n.name == 'Terrain (Required)':
            from_node = n.links[0].from_node
            width = from_node.get_width()
            height = from_node.get_height()
            ### 
            if width * height > 1048576:
               raise Exception("Trial Only: Erosion is limited to 1024x1024 resolution, please lower input size.")

        if n.is_linked:
            print('--', n.name, from_node.name)
        layers[n.name] = tn_data.get_socket_data(n, deepcopy=True)

    for key in layers:
        if layers[key] is None and key != 'Rain Mask':
            print('Empty: ', key)
            layers[key] = numpy.zeros(width * height, dtype=numpy.float32)

    for key in layers:
        if layers[key] is not None:
            if len(layers[key]) != width * height:
                print('Error, wrong size input: ', key)
                return None

    dll_erosion.init(
        ctypes.c_void_p(layers['Terrain (Required)'].ctypes.data),
        ctypes.c_void_p(layers['Water'].ctypes.data),
        ctypes.c_void_p(layers['Sediment'].ctypes.data),
        ctypes.c_void_p(layers['Rock'].ctypes.data),
        ctypes.c_void_p(layers['Rigolith'].ctypes.data),
        ctypes.c_void_p(layers['Suspended Sediment'].ctypes.data),
        ctypes.c_int(width),
        ctypes.c_int(height)
        )

    dll_erosion.set_constants(
        ctypes.c_float(node.pipe_length),
        ctypes.c_float(node.time_step),
        ctypes.c_float(node.sediment_dissolve_const),
        ctypes.c_float(node.terrain_dissolve_const),
        ctypes.c_float(node.rock_dissolve_const)
        )

    if node.noise_height > 0:
        dll_erosion.gen_noise(
            ctypes.c_float(node.noise_height),
            ctypes.c_int(node.noise_seed)
            )

    cycle_count = 0
    total_time_running = 0
    last_print_time = 0
    cycles = node.total_cycles
    while cycles > 0:
        time_start = time.time()

        if cycle_count % node.rain_freq == 0 and cycle_count < node.rain_duration:
            rain_mask = None

            if layers['Rain Mask'] is not None:
                rain_mask = layers['Rain Mask'].ctypes.data

            if node.basic_rain:
                dll_erosion.basic_rain(
                    ctypes.c_float(node.rain_min),
                    ctypes.c_float(node.rain_max),
                    ctypes.c_int(cycle_count),
                    ctypes.c_void_p(rain_mask)
                    )
            else:
                dll_erosion.rain(
                    ctypes.c_void_p(rain_mask),
                    ctypes.c_int(node.droplets),
                    ctypes.c_int(node.radius),
                    ctypes.c_float(node.rain_min),
                    ctypes.c_float(node.rain_max),
                    ctypes.c_int(cycle_count)
                    )

        dll_erosion.calc_slope(ctypes.c_float(node.edge_length))

        dll_erosion.water_simulation(
            ctypes.c_bool(node.bounded),
            ctypes.c_float(node.flow_fric_coef),
            )

        if node.rain_pre_cycles < cycle_count:
            #dll_erosion.sample_water_velocity() #######

            dll_erosion.update_water_velocity(
                ctypes.c_float(node.min_water_height)
                )

            dll_erosion.update_sediment_carry(
                ctypes.c_float(node.min_tilt_angle)
                )

            if node.deposit_const > 0:
                dll_erosion.deposition(
                    ctypes.c_float(node.deposit_const)
                    )

            if node.hydro_erosion == True:
                dll_erosion.hydro_erosion()

            # # # if node.hydro_erosion == True:
            # # #     dll_erosion.hydro_erosion_combined()

            if node.bank_erosion == True:
                dll_erosion.bank_erosion(
                    ctypes.c_float(node.bank_erosion_strength)
                    )

            if node.dissol_erosion == True:
                dll_erosion.dissolution_erosion(
                    ctypes.c_float(node.dissol_max_depth),
                    ctypes.c_float(node.dissol_time_step)
                    )

            if node.slippage_erosion == True:
                dll_erosion.slippage_erosion(
                    ctypes.c_float(node.slip_talus_angle),
                    ctypes.c_float(node.slip_time_step)
                    )

            dll_erosion.transport_sediment()

            # # # dll_erosion.diffuse_suspended_sediment(
            # # #     ctypes.c_float(node.diffuse_time_step)
            # # #     )

        if node.dry_rate > 0:
            dll_erosion.evaporation(
                ctypes.c_float(node.dry_rate)
                )

        time_stop = time.time()

        total_time_running += (time_stop - time_start)
        cycle_count += 1

        if total_time_running - last_print_time >= 1:
            last_print_time = total_time_running
            avg_time = total_time_running / cycle_count
            print('    Elapsed time:\t{}'.format(str(timedelta(seconds = total_time_running))))
            print('    Time left:\t\t{}'.format(str(timedelta(seconds = avg_time * (node.total_cycles - cycle_count)))))
            print()

        cycles -= 1

    print('Returning data from DLL')
    dll_erosion.move_data(
        ctypes.c_void_p(layers['Terrain (Required)'].ctypes.data),
        ctypes.c_void_p(layers['Water'].ctypes.data),
        ctypes.c_void_p(layers['Sediment'].ctypes.data),
        ctypes.c_void_p(layers['Rock'].ctypes.data),
        ctypes.c_void_p(layers['Rigolith'].ctypes.data),
        ctypes.c_void_p(layers['Suspended Sediment'].ctypes.data)
        )

    dll_erosion.free_device_mem()

    return layers
