import bpy

class GAEA_PT_main(bpy.types.Panel):
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_label = "Terrain Editor"
    bl_context = 'scene'

    @classmethod
    def poll(self, context):
        if context.space_data.node_tree:
            return context.space_data.node_tree.bl_idname == 'terrain_master'
        return False
        # if context.scene.node_tree.nodes.active:
        #     # https://blender.stackexchange.com/questions/68349/how-to-access-node-tree-of-a-selected-node-group-in-python
        #     return context.scene.node_tree.nodes.active.parent.bl_idname == 'terrain_master'
    
    def draw(self, context):
        layout = self.layout
        col = layout.column()
