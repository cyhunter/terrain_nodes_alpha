import bpy
import ctypes
import numpy

def save_image(tn_render_scene, st, node, data, input_data, key, dll_erosion):
    width = node.get_width()
    height = node.get_height()
    image_name = key + node.output_name

    if data and image_name in data:
        image = data[image_name]
        if image.size[0] != width or image.size[1] != height:
            image.generated_width = width
            image.generated_height = height
    else:
        image = bpy.data.images.new(name=image_name, width=width, height=height, alpha=False, float_buffer=True)

    image.colorspace_settings.name = 'Non-Color'

    pixels = numpy.empty(width * height * 4, dtype=numpy.float32)

    dll_erosion.value_to_pixels(
        ctypes.c_void_p(input_data.ctypes.data), 
        ctypes.c_void_p(pixels.ctypes.data),
        ctypes.c_int(width * height))

    image.pixels = pixels.tolist()
    image.update()
    
    if node.directory.startswith('//'):
        rel_path = bpy.path.abspath(node.directory)
        filepath = '{}\\{}.exr'.format(rel_path, image_name)
    else:
        filepath = '{}\\{}.exr'.format(node.directory, image_name)

    image.save_render(filepath=filepath, scene=tn_render_scene)

    st[key] = image

    print('Image saved to ', filepath)