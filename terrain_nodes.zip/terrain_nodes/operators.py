import bpy

class GAEA_OT_bake_nodes_modal(bpy.types.Operator):
    bl_idname = "scene.bake_nodes_modal"
    bl_label = "Bake Output M"

    output_node = None
    tn_data = None
    redraw = True
    prev_node = None
    node = None

    @classmethod
    def poll(self, context):
        return True

    def modal(self, context, event):
        if self.node is None or event.type in ('ESC'):
            if self.prev_node:
                self.prev_node.use_custom_color = False
            
            for img in bpy.data.images:
                img.reload()
                
            context.window_manager.event_timer_remove(self._timer)

            return {'FINISHED'}

        if self.redraw:
            if self.prev_node:
                self.prev_node.use_custom_color = False
            if self.node.bl_idname == 'GAEA_ND_viewer' and self.node.tex:
                self.node.width -= 1

            self.node.use_custom_color = True
            self.node.color = (0,1,0)
            self.redraw = False

            for area in context.screen.areas:
                area.tag_redraw()
                    
            return {'PASS_THROUGH'}

        elif event.type == 'TIMER' and self.node.use_custom_color == True:
            self.tn_data.compute_node(self.node)
            self.prev_node = self.node
            self.redraw = True

            if self.node.bl_idname == 'GAEA_ND_viewer' and self.node.tex:
                self.node.width += 1
            
            self.node = self.tn_data.get_node()
                    
        for area in context.screen.areas:
            area.tag_redraw()

        return {'PASS_THROUGH'}

    def execute(self, context):
        print('Executing..')
        self.tn_data = context.scene.terrain_nodes_data

        self.tn_data.init(context.node)
        self.tn_data.reset_node_list()
        self.tn_data.build_node_list(context.node)
        self.node = self.tn_data.get_node()

        wm = context.window_manager
        self._timer = wm.event_timer_add(time_step=0.4, window=context.window) 
        wm.modal_handler_add(self)

        return {'RUNNING_MODAL'}