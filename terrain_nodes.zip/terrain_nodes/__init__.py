bl_info = {
    "name" : "Terrain Nodes",
    "author" : "Valeri Barashkov",
    "version": (0, 1, 0, 0),
    "blender": (2, 80, 0),
    "location": "Editor Type > Terrain Nodes",
    "description" : "Node based height map generation",
    "warning": "Erosion is limited to 1024x1024. \nNot for production use, this is still early alpha.",
    "tracker_url": "mailto:Val.barashkov@gmail.com",
    "category": "Nodes"
}

import bpy
import inspect
import nodeitems_utils
from nodeitems_utils import NodeCategory, NodeItem

from . nodes import *
from . data_structure import *
from . panel import *
from . operators import *

classes = [
    GAEA_PT_main,
    GAEA_OT_bake_nodes_modal,
]

node_items = []
for name, obj in inspect.getmembers(nodes, inspect.isclass):
    if 'GAEA' in name:
        classes.append(obj)
        if '_ND_' in name:
            node_items.append(NodeItem(obj.bl_idname, label=obj.bl_label))
            
# our own base class with an appropriate poll function,
# so the categories only show up in our own tree type
class GAEA_node_category(NodeCategory):
    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == 'terrain_nodes'

# node_categories = [
#     GAEA_node_category('INPUTNODES', 'Input', items=['GAEA_ND_image_input', 'GAEA_ND_object_input']),
#     GAEA_node_category('OUTPUTNODES', 'Output', items=['GAEA_ND_output', 'GAEA_ND_viewer']),
#     GAEA_node_category('GENERATENODES', 'Generate', items=['GAEA_ND_noise_texture']),
#     GAEA_node_category('FILTERNODES', 'Filter', items=['GAEA_ND_terrain_erosion']),
#     GAEA_node_category('TRANSFORMNODES', 'Transform', items=['GAEA_ND_math', 'GAEA_ND_scale']),
# ]

node_categories = [
    GAEA_node_category('OTHERNODES', 'All', items=node_items),
]

def register():
    bpy.types.Scene.terrain_nodes_data = GAEA_data_structure()

    for c in classes:
        bpy.utils.register_class(c)

    nodeitems_utils.register_node_categories('CUSTOM_NODES', node_categories)


def unregister():
    nodeitems_utils.unregister_node_categories('CUSTOM_NODES')

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    del bpy.types.Scene.terrain_nodes_data


if __name__ == '__main__':
    register()