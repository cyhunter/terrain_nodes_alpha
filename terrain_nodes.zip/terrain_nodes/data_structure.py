import bpy
import copy
from . computes import compute_functions# Computes

class GAEA_data_structure():
    def __init__(self):
        self.state = {}
        self.node_order_list = []

    def init(self, output_node):
        tree_name = output_node.id_data.name
        node_tree = bpy.data.node_groups[tree_name].nodes

        # Create state entry if none
        for node in node_tree:
            node.use_custom_color = False
            node.color = (0,0,0)

            if node.name not in self.state:
                self.state[node.name] = None
                node.set_state(True)

        # Check if node is dirty, remove data of dirty node
        # Clean viewer nodes
        for node in node_tree:
            if node.get_state():
                self.state[node.name] = None
                print('Cleaned node ', node.name)

        del_table = []
        for key in self.state:
            present = False
            for node in node_tree:
                if key == node.name:
                    present = True
            if not present:
                del_table.append(key)
        
        for key in del_table:
            print('Removing data of missing node', key)
            del self.state[key]

    def build_node_list(self, node):
        for n in node.inputs:
            if n.is_linked and n.links[0].from_node.name:
                self.build_node_list(n.links[0].from_node)

        if node not in self.node_order_list:
            self.node_order_list.append(node)

        # check for viewer node and insert after
        for o in node.outputs:
            if o.is_linked:
                for l in o.links:
                    if l.to_node.bl_idname == 'GAEA_ND_viewer' and l.to_node not in self.node_order_list:
                        self.node_order_list.append(l.to_node)

    def get_node(self):
        if len(self.node_order_list) != 0:
            return self.node_order_list.pop(0)

    def reset_node_list(self):
        self.node_order_list = []

    def get_socket_data(self, n, deepcopy=False):
        if n and n.is_linked:
            from_node = n.links[0].from_node
            input_data = self.state[from_node.name]
            socket_name = n.links[0].from_socket.name
            if deepcopy:
                return(copy.deepcopy(input_data[socket_name]))
            else:
                return input_data[socket_name]
        else:
            try:
                return n.default_value
            except:
                pass

    def compute_node(self, node):
        print('Computing:', node.name)
        if self.state[node.name] is None or node.bl_idname == 'GAEA_ND_output':
            compute = compute_functions.get(node.bl_idname)
            self.state[node.name] = compute(self, node)
            node.set_state(False)
        else:
            print('Skipping node {} data is updated..'.format(node.name))
