import copy
import bpy
from bpy.types import NodeTree, Node, NodeSocket
from bpy.props import *


# recursively notifies nodes of update down the branch
def reset_branch_state(self, context=None):
    if self.bl_idname == 'GAEA_ND_output':
        return

    self.set_state(True)
    for socket in self.outputs:
        if socket.is_linked:
            for link in socket.links:
                reset_branch_state(link.to_node)

# detects if node needs updating, call reset_branch_state if update is needed
def on_socket_change(self):
    ''' Erase data down the tree since it is no longer valid. '''
    if len(self.inputs) == 0:
        return

    current_links = []
    prev_links = self.socket_states.split(',')

    for inp in self.inputs:
        if inp.is_linked:
            try:
                current_links.append(inp.name + inp.links[0].from_node.name)
            except IndexError:
                pass
    
    if prev_links == [] and current_links == []:
        return

    # check if new link was added
    for key in current_links:
        if key not in prev_links:
            reset_branch_state(self)

    # check if link was removed
    for key in prev_links:
        if key not in current_links:
            reset_branch_state(self)

    if current_links != []:
        self.socket_states = ",".join(current_links)


class Poll:
    bl_idname = 'terrain_nodes_poll'
    bl_label = 'Terrain Nodes Poll'

    @classmethod
    def poll(self, node_tree):
        return node_tree.bl_idname == 'terrain_nodes'

# Adds program to nodes type panel
class GAEA_terrain_nodes(NodeTree):
    bl_idname = 'terrain_nodes'
    bl_label = 'Terrain Nodes'
    bl_icon = 'NODETREE'
    bl_type = 'GAEA'

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        snode = context.space_data
        snode_id = snode.id
        id_from = snode.id_from
        toolsettings = context.tool_settings

        row = layout.row(align=True)
        row.template_header()

        layout.prop(snode, 'tree_type', text='', expand=True)

        layout.template_ID(snode, 'node_tree', new='node.new_node_tree')


# Custom socket type
class GAEA_value_texture_socket(NodeSocket):
    bl_idname = 'GAEA_value_texture_socket'
    bl_label = 'Value Texture Socket'
    bl_type = 'GAEA'

    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked:
            layout.label(text)
        else:
            layout.prop(self, 'myEnumProperty', text=text)

    # Socket color
    def draw_color(self, context, node):
        return (1.0, 0.4, 0.216, 0.5)

# Image input node
class GAEA_ND_math(Node, Poll):
    bl_idname = 'GAEA_ND_math'
    bl_label = 'Math'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'

    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    func_types = [
        ('add', 'Add', 'D'),
        ('subtract', 'Subtract', 'D'),
        ('multiply', 'Multiply ', 'D'),
        ('divide', 'Divide', 'D'),
    ]

    functions : EnumProperty(
        name='', 
        description='Select math functions', 
        items=func_types, 
        default='add',
        update=reset_branch_state)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    def get_width(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_width()
        else:
            return None
    
    def get_height(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_height()
        else:
            return None

    def init(self, context):
        self.inputs.new('NodeSocketFloat', 'A')
        self.inputs.new('NodeSocketFloat', 'B')
        self.outputs.new('NodeSocketShader', 'Value')

    def copy(self, node):
        print('Copying from node ', node)

    def free(self):
        print('Removing node ', self, ', Goodbye!')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'functions')

    def draw_buttons_ext(self, context, layout):
        pass

    def update(self):
        on_socket_change(self)

# Image input node
class GAEA_ND_scale(Node, Poll):
    bl_idname = 'GAEA_ND_scale'
    bl_label = 'Scale'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'

    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    scale_width : IntProperty(
        name='New Width', 
        default=256,
        min = 0,
        update=reset_branch_state)
    scale_height : IntProperty(
        name='New Height', 
        default=256,
        min = 0,
        update=reset_branch_state)

    def get_width(self):
        return self.scale_width
    
    def get_height(self):
        return self.scale_height

    def init(self, context):
        self.inputs.new('NodeSocketShader', 'Value')
        self.outputs.new('NodeSocketShader', 'Value')

    def copy(self, node):
        print('Copying from node ', node)

    def free(self):
        print('Removing node ', self, ', Goodbye!')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'scale_width')
        layout.prop(self, 'scale_height')

    def draw_buttons_ext(self, context, layout):
        pass

    def update(self):
        on_socket_change(self)

# Image input node
class GAEA_ND_viewer(Node, Poll):
    bl_idname = 'GAEA_ND_viewer'
    bl_label = 'Viewer'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'

    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    tex : PointerProperty(
        name='viewer_texture',
        type=bpy.types.Texture)

    preview_resolution : IntProperty(
        name='Preview Resolution Reduction', 
        default=4,
        min=1,
        update=reset_branch_state)

    def get_width(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_width()
        else:
            return None
    
    def get_height(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_height()
        else:
            return None

    def init(self, context):
        self.inputs.new('NodeSocketShader', 'Value')

    def copy(self, node):
        print('Copying from node ', node)

    def free(self):
        print('Removing node ', self, ', Goodbye!')

    def draw_buttons(self, context, layout):
        layout.prop(self, 'preview_resolution')
        if self.tex:
            layout.template_preview(self.tex)

    def draw_buttons_ext(self, context, layout):
        pass

    def update(self):
        on_socket_change(self)

# Image input node
class GAEA_ND_image_input(Node, Poll):
    bl_idname = 'GAEA_ND_image_input'
    bl_label = 'Image Select'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'

    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty=flag
    def get_state(self):
        return self.is_dirty

    image : PointerProperty(
        name='Image', 
        type=bpy.types.Image, 
        update=reset_branch_state)

    def get_width(self):
        return self.image.size[0]
    
    def get_height(self):
        return self.image.size[1]

    def init(self, context):
        self.outputs.new('NodeSocketShader', 'Value')

    def copy(self, node):
        print('Copying from node ', node)

    def free(self):
        print('Removing node ', self, ', Goodbye!')

    def draw_buttons(self, context, layout):
        layout.template_ID(self, 'image', open='image.open')

    def draw_buttons_ext(self, context, layout):
        pass

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    #def draw_label(self):
    #    return 'Select Image'
    
    # def update(self):
    #     on_socket_change(self)


# Derived from the Node base type.
class GAEA_ND_output(Node, Poll):
    bl_idname = 'GAEA_ND_output'
    bl_label = 'Output'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'
    
    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    # width = IntProperty(
    #     name = 'Image Width',
    #     min = 0,
    #     default = 512,
    # )
    # height = IntProperty(
    #     name = 'Image Height',
    #     min = 0,
    #     default = 512,
    # )
    directory : StringProperty(
        subtype='DIR_PATH',
        name='Save location')
    output_name : StringProperty(
        name='Output Name'
    )
    save_all : BoolProperty(
        name='Save All Layers',
        default=True
    )
    # sediment = StringProperty()
    # rock = StringProperty()
    # water = StringProperty()
    # susp_sed = StringProperty()
    # rigolith = StringProperty()
    # water_vel = StringProperty()
    # slope = StringProperty()

    def get_width(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_width()
        else:
            return None
    
    def get_height(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_height()
        else:
            return None
            
    def draw_buttons(self, context, layout):
        layout.prop(self, 'directory')
        layout.prop(self, 'output_name')
        # layout.prop(self, 'sediment')
        # layout.prop(self, 'rock')
        # layout.prop(self, 'water')
        # layout.prop(self, 'susp_sed')
        # layout.prop(self, 'water_vel')
        # layout.prop(self, 'slope')
        
        if self.inputs[0].is_linked:
            #layout.operator('scene.bake_nodes')
            layout.operator('scene.bake_nodes_modal')

    def init(self, context):
        self.inputs.new('NodeSocketShader', 'Value Texture')

    def update(self):
        on_socket_change(self)


# Derived from the Node base type.
class GAEA_ND_noise_texture(Node, Poll):
    bl_idname = 'GAEA_ND_noise_texture'
    bl_label = 'Noise Texture'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'
    
    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    noise_types = [
        ('0', 'Blender', 'D'),
        ('1', 'Perlin', 'D'),
        ('2', 'New Perlin ', 'D'),
        ('14', 'Cell Noise', 'D'),
        ('3', 'Vornoi_F1', 'D'),
        ('4', 'Vornoi_F2', 'D'),
        ('5', 'Vornoi_F3', 'D'),
        ('6', 'Vornoi_F4', 'D'),
        ('7', 'Vornoi_F2F1', 'D'),
        ('8', 'Vornoi_Crackle', 'D'),
    ]
    noises : EnumProperty(
        name='Noise Type', 
        description='Select noise type', 
        items=noise_types, 
        default='0',
        update=reset_branch_state)

    noise_limit_types = [
        ('abs', 'Absolute', 'Convert to positive'),
        ('zero', 'Above Zero Only', 'Limit to positive values'),
        ('none', 'None', 'No limits')
    ]
    noise_limits : EnumProperty(
        name='Limit', 
        description='Limit noise results', 
        items=noise_limit_types, 
        default='none',
        update=reset_branch_state)

    noise_width : IntProperty(
        name='Image Width', 
        default=256,
        min = 0,
        update=reset_branch_state)
    noise_height : IntProperty(
        name='Image Height', 
        default=256,
        min = 0,
        update=reset_branch_state)
    # Noise scale multiplier
    scale : FloatProperty(
        name='Noise Scale', 
        default=0.005, 
        min = 0,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)
    # H (float) – The fractal dimension of the roughest areas.
    factal_dim : FloatProperty(
        name='Fractal Dimension', 
        default=1.0,
        min = 0,
        precision = 2,
        step = 1,
        update=reset_branch_state)
    # lacunarity (float) – The gap between successive frequencies.
    lacunarity : FloatProperty(
        name='Lacunarity (frequency gap)', 
        default=2.0, 
        min = 0,
        precision = 2,
        step = 1,
        update=reset_branch_state)
    # octaves (int) – The number of different noise frequencies used.
    octaves : IntProperty(
        name='Octaves', 
        default=1, 
        min = 0,
        update=reset_branch_state)
    # offset (float) – The height of the terrain above ‘sea level’.
    offset : FloatProperty(
        name='Offset', 
        default=1.0, 
        min = 0,
        precision = 2,
        step = 1,
        update=reset_branch_state)

    def get_width(self):
        return self.noise_width
    
    def get_height(self):
        return self.noise_height

    def draw_buttons(self, context, layout):
        layout.prop(self, 'noise_limits')
        layout.prop(self, 'noise_width')
        layout.prop(self, 'noise_height')
        layout.prop(self, 'scale')
        layout.prop(self, 'factal_dim')
        layout.prop(self, 'lacunarity')
        layout.prop(self, 'octaves')
        layout.prop(self, 'offset')
        layout.prop(self, 'noises')

    def init(self, context):
        self.outputs.new('NodeSocketShader', 'Value Texture')

    # def update(self):
    #     on_socket_change(self)
    

# Derived from the Node base type.
class GAEA_ND_object_input(Node, Poll):
    bl_idname = 'GAEA_ND_object_input'
    bl_label = 'Object Input'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'
    
    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    target_object : PointerProperty(
        type=bpy.types.Object,
        update=reset_branch_state)
    object_width : IntProperty(
        name='Image Width')
    object_height : IntProperty(
        name='Image height')

    def get_width(self):
        return self.object_width
    
    def get_height(self):
        return self.object_height

    def draw_buttons(self, context, layout):
        layout.prop_search(self, 'target_object', context.scene, 'objects', text='')

    def init(self, context):
        self.outputs.new('NodeSocketShader', 'Value Texture')

    def update(self):
        on_socket_change(self)


# Terrain erosion node
class GAEA_ND_terrain_erosion(Node, Poll):
    bl_idname = 'GAEA_ND_terrain_erosion'
    bl_label = 'Erosion Filter'
    bl_icon = 'SOUND'
    bl_type = 'GAEA'
    
    # Previous socket state, to varify node needs updating
    socket_states : StringProperty(default='')
    is_dirty : BoolProperty(default=True)

    def set_state(self, flag):
        self.is_dirty = flag
    def get_state(self):
        return self.is_dirty

    current_cycle : IntProperty()

    '''SIMULATION SETTINGS'''
    total_cycles : IntProperty(
        name = 'Cycles', 
        min = 1,
        default = 4000,
        update=reset_branch_state)
    bounded : BoolProperty(
        name = 'Closed Boundry',
        default = False,
        update=reset_branch_state)
    min_water_height : FloatProperty(
        name = 'Velocity Limiter', 
        min = 0,
        default = 0.01,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)
    pipe_length : FloatProperty(
        name = 'Pixel Length', 
        min = 0.0001,
        default = 1,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)
    time_step : FloatProperty(
        name = 'Time Step', 
        min = 0.000001,
        default = 0.001,
        precision = 5,
        step = 0.01,
        update=reset_branch_state)
    edge_length : FloatProperty(
        name='Slope Multiplier',
        min = 0.00001,
        default = 0.01,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)
    min_tilt_angle : FloatProperty(
        name = 'Minimum Tilt Angle', 
        min = 0,
        max = 90,
        default = 5,
        step = 100,
        update=reset_branch_state)
    rain_pre_cycles : IntProperty(
        name = 'Pre-simulate Water Cycles', 
        min = 0,
        default = 0,
        update=reset_branch_state)
    noise_height : FloatProperty(
        name = 'Noise Max', 
        min = 0,
        default = 0,
        precision = 5,
        step = 0.001,
        update=reset_branch_state)
    noise_seed : IntProperty(
        name = 'Noise Seed', 
        min = 0,
        default = 0,
        update=reset_branch_state)
    # vel_math_type : EnumProperty(
    #     items = [('None', 'None', 'No water velocity change', 1), 
    #              ('Add', 'String', 'Addition', 2),
    #              ('Multiply', 'String', 'Addition', 2)],
    #     name = 'Velocity Multiplier',
    #     default = 'None',
    #     update=reset_branch_state)
    # x_vel : FloatProperty(
    #     name = 'X Velocity', 
    #     min = 0,
    #     default = 0,
    #     step = 10,
    #    update=reset_branch_state)
    # y_vel : FloatProperty(
    #     name = 'Y Velocity', 
    #     min = 0,
    #     default = 0,
    #     step = 10,
    #     update=reset_branch_state)

    '''EROSION SETTINGS'''
    hydro_erosion : BoolProperty(
        name = 'Hydrolic Erosion',
        default = True,
        update=reset_branch_state)
    dissol_erosion : BoolProperty(
        name = 'Dissolution Erosion',
        default = False,
        update=reset_branch_state)
    dissol_time_step : FloatProperty(
        name = 'Time Step', 
        min = 0,
        default = 0.001,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)
    dissol_max_depth : FloatProperty(
        name = 'Dissolution Strength', 
        min = 0.000000001,
        default = 0.00001,
        precision = 6,
        step = 0.01,
        update=reset_branch_state)
    slippage_erosion : BoolProperty(
        name = 'Sediment Slope Erosion',
        default = False,
        update=reset_branch_state)
    slippage_talus_angle : FloatProperty(
        name = 'Maximum Stable Slope', 
        min = 0,
        max = 90,
        default = 5,
        step = 1,
        update=reset_branch_state)
    slippage_time_step : FloatProperty(
        name = 'Time Step', 
        min = 0,
        default = 1,
        precision = 4,
        step = 0.001,
        update=reset_branch_state)
    bank_erosion : BoolProperty(
        name = 'Bank Erosion',
        default = False,
        update=reset_branch_state)
    bank_erosion_strength : FloatProperty(
        name = 'Bank Erosion Strength', 
        min = 0,
        default = 0.00002,
        precision = 6,
        step = 0.001,
        update=reset_branch_state)
    diffuse_susp_sediment : BoolProperty(
        name = 'Enable DSS')
    diffuse_time_step : FloatProperty(
        name = 'Time Step',
        min = 0,
        default = 0.01,
        precision = 5,
        step = 0.001,
        update=reset_branch_state)
    deposit_const : FloatProperty(
        name = 'Sediment Deposit Rate', 
        min = 0,
        default = 0.001,
        precision = 7,
        step = 0.0001,
        update=reset_branch_state)
    rock_dissolve_const : FloatProperty(
        name = 'Rock Dissolve Rate', 
        min = 0,
        default = 0.000001,
        precision = 7,
        step = 0.0001,
        update=reset_branch_state)
    terrain_dissolve_const : FloatProperty(
        name = 'Terrain Dissolve Rate', 
        min = 0,
        default = 0.00001,
        precision = 7,
        step = 0.0001,
        update=reset_branch_state)
    sediment_dissolve_const : FloatProperty(
        name = 'Sediment Dissolve Rate', 
        min = 0,
        default = 0.001,
        precision = 7,
        step = 0.0001,
        update=reset_branch_state)
    flow_fric_coef : FloatProperty(
        name = 'Flow Friction', 
        min = 0,
        default = 0.001,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)
    dry_rate : FloatProperty(
        name = 'Dry Rate', 
        min = 0,
        default = 0,
        precision = 4,
        step = 0.01,
        update=reset_branch_state)

    ''' RAIN '''
    rain_freq : IntProperty(
        name = 'Rain Frequency', 
        min = 1,
        default = 1000,
        update=reset_branch_state)
    rain_duration : IntProperty(
        name = 'Rain Duration', 
        min = 0,
        default = 2000,
        update=reset_branch_state)
    droplets : IntProperty(
        name = 'Number of Droplets', 
        min = 0,
        default = 1000,
        update=reset_branch_state)
    radius : IntProperty(
        name = 'Drop Radius', 
        min = 1,
        default = 4,
        update=reset_branch_state)
    rain_min : FloatProperty(
        name = '', 
        min = 0,
        default = 0,
        precision = 6,
        step = 0.001,
        update=reset_branch_state)
    rain_max : FloatProperty(
        name = '', 
        min = 0,
        default = 0.0001,
        precision = 6,
        step = 0.001,
        update=reset_branch_state)
    basic_rain : BoolProperty(
        name = 'Basic Rain',
        update=reset_branch_state)

    '''UTILS'''
    def get_width(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_width()
        else:
            return None
    
    def get_height(self):
        if self.inputs[0].is_linked:
            return self.inputs[0].links[0].from_node.get_height()
        else:
            return None

    def init(self, context):
        self.inputs.new('NodeSocketShader', 'Terrain (Required)')
        self.inputs.new('NodeSocketShader', 'Water')
        self.inputs.new('NodeSocketShader', 'Sediment')
        self.inputs.new('NodeSocketShader', 'Rock')
        self.inputs.new('NodeSocketShader', 'Rigolith')
        self.inputs.new('NodeSocketShader', 'Suspended Sediment')
        self.inputs.new('NodeSocketShader', 'Rain Mask')

        self.outputs.new('NodeSocketShader', 'Terrain (Required)')
        self.outputs.new('NodeSocketShader', 'Water')
        self.outputs.new('NodeSocketShader', 'Sediment')
        self.outputs.new('NodeSocketShader', 'Rock')
        self.outputs.new('NodeSocketShader', 'Rigolith')
        self.outputs.new('NodeSocketShader', 'Suspended Sediment')
        self.outputs.new('NodeSocketShader', 'Slope')
        self.outputs.new('NodeSocketShader', 'Water Velocity')

    def copy(self, node):
        print('Copying from node ', node)

    def free(self):
        print('Do data clean up here')

    def update(self):
        on_socket_change(self)

    '''UI'''
    def draw_buttons(self, context, layout):
        col = layout.row()
        split = col.split()
        box = split.column().box()
 
        bcol = box.column()
        bcol.label(text='Simulation Settings:')
        bcol.prop(self, 'total_cycles')
        bcol.prop(self, 'rain_pre_cycles')
        bcol.prop(self, 'time_step')
        bcol.prop(self, 'pipe_length')
        bcol.prop(self, 'min_water_height')

        col = layout.row()
        split = col.split()
        box = split.column().box()
        bcol = box.column()
        bcol.label(text='Water Settings:')
        bcol.prop(self, 'bounded')
        bcol.prop(self, 'dry_rate')
        bcol.prop(self, 'flow_fric_coef')
        bcol.prop(self, 'noise_height')
        bcol.prop(self, 'noise_seed')

        col = layout.row()
        split = col.split()
        box = split.column().box()
        bcol = box.column()
        bcol.label(text='Rain Settings:')
        bcol.prop(self, 'rain_duration')

        bcol = box.column()
        bcol.enabled = self.rain_duration > 0
        row = bcol.row(align=True)
        bcol.prop(self, 'rain_freq')
        row = bcol.row(align=True)

        bcol = box.column()
        bcol.enabled = self.rain_duration > 0
        bcol.label(text='Rain min/max')
        row = bcol.row(align=True)
        row.prop(self, 'rain_min')
        row.prop(self, 'rain_max')
        bcol.prop(self, 'basic_rain')

        bcol = box.column()
        bcol.enabled = self.rain_duration > 0 and self.basic_rain == False
        bcol.prop(self, 'droplets')
        bcol.prop(self, 'radius')

        col = layout.row()
        split = col.split()
        box = split.column().box()
        bcol = box.column()
        bcol.label(text='Erosion Settings:')
        bcol.prop(self, 'min_tilt_angle')
        bcol.prop(self, 'edge_length')
        bcol.prop(self, 'deposit_const')
        bcol.prop(self, 'sediment_dissolve_const')
        bcol.prop(self, 'terrain_dissolve_const')
        bcol.prop(self, 'rock_dissolve_const')

        bcol.prop(self, 'hydro_erosion')

        bcol = box.column()
        bcol.prop(self, 'bank_erosion')
        bcol = box.column()
        bcol.enabled = self.bank_erosion
        bcol.prop(self, 'bank_erosion_strength')

        bcol = box.column()
        bcol.prop(self, 'dissol_erosion')
        bcol = box.column()
        bcol.enabled = self.dissol_erosion
        bcol.prop(self, 'dissol_max_depth')
        bcol.prop(self, 'dissol_time_step')

        bcol = box.column()
        bcol.prop(self, 'diffuse_susp_sediment')
        bcol = box.column()
        bcol.enabled = self.diffuse_susp_sediment
        bcol.prop(self, 'diffuse_time_step')

        col = layout.row()
        split = col.split()
        box = split.column().box()
        bcol = box.column()
        bcol.prop(self, 'slippage_erosion')
        bcol = box.column()
        bcol.enabled = self.slippage_erosion
        bcol.prop(self, 'slippage_talus_angle')
        bcol.prop(self, 'slippage_time_step')